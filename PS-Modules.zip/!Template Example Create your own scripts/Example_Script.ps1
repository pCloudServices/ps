###########################################################################
#
# NAME: Script Example
#
# AUTHOR:  <Your name here>
#
# COMMENT: 
# <Short Description on what the script does.>
#
#
###########################################################################

# Prompt for neccassry params to run at the start of the script.
param(
    [ValidateScript({
        If(![string]::IsNullOrEmpty($_)) {
            $isValid = ($_ -like "*.privilegecloud.cyberark.cloud*") -or ($_ -like "*.cyberark.cloud*") -or ($_ -like "*.privilegecloud.cyberark.com*") -or ($_ -like "*.cyberark.com*")
            if (-not $isValid) {
                throw "Invalid URL format. Please specify a valid Privilege Cloud tenant URL (e.g.https://<subdomain>.cyberark.cloud)."
            }
            $true
        }
        Else {
            $true
        }
    })]
    [Parameter(Mandatory = $true, HelpMessage = "Specify the URL of the Privilege Cloud tenant (e.g., https://<subdomain>.cyberark.cloud)")]
    [string]$PortalURL,
    [Parameter(Mandatory = $true, HelpMessage = "Specify a User that has minimum required permissions.")]
    [PSCredential]$Credentials
)




# Modules
$mainModule = "Import_AllModules.psm1"

# Potential Module locations
$modulePaths = @(
"..\\PS-Modules\\$mainModule",
"..\\..\\PS-Modules\\$mainModule",
".\\PS-Modules\\$mainModule", 
".\\$mainModule"
"..\\$mainModule"
".\\..\\$mainModule"
"..\\..\\$mainModule"
)

# Load all modules at the start of the script
foreach ($modulePath in $modulePaths) {

    if (Test-Path $modulePath) {
        try {
            Import-Module $modulePath -ErrorAction Stop -DisableNameChecking -Force
        } catch {
            Write-Host "Failed to import module from $modulePath. Error: $_"
            Write-Host "check that you copied the PS-Modules folder correctly."
            Pause
            Exit
        }
     }
}

# Define output log
$ScriptLocation = Split-Path -Parent $MyInvocation.MyCommand.Path # You can user hardocded path here for troubleshooting from inside ISE editor
$global:LOG_FILE_PATH = "$ScriptLocation\_Example_Script.log"

# Update this everytime you release a new version
[int]$scriptVersion = 1

# Set a custom PS Window title
$Host.UI.RawUI.WindowTitle = "Privilege Cloud Example Script"

## Force Output to be UTF8 (for OS with different languages)
$OutputEncoding = [Console]::InputEncoding = [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding # This will error in ISE, but will work in normal ps window.
   
# Build PVWA Urls
$platformURLs = DetermineTenantTypeURLs -PortalURL $PortalURL
$IdentityAPIURL = $platformURLs.IdentityURL
$pvwaAPI = $platformURLs.PVWA_API_URLs.PVWAAPI
# DPA TBA
# CM TBA

# Handle Login
$global:logonheader = Authenticate-Platform -platformURLs $platformURLs -creds $Credentials


# Main Script starts here

# Example 1 - Get a list of identity Users
$Get_IdentityUsers = Invoke-RestMethod -Method Post -Uri "$IdentityAPIURL/CDirectoryService/GetUsers" -ContentType "application/json" -Headers $logonheader
$Get_IdentityUsers.Result.Results.Row.Name

# Example 2 - Get a list of Vault Users:
$Get_VaultUsers = Invoke-RestMethod -Method Get -Uri "$pvwaAPI/Users" -ContentType "application/json" -Headers $logonheader
$Get_VaultUsers.Users.username






###########################################################
########## Pass the Token to PsPAS tool (Pspete's github)
###########################################################

$token = $logonheader.Authorization -replace '^Bearer\s+', ''

# 1) Build a WebRequestSession and add your Identity headers
$web = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$web.Headers['Authorization']        = "Bearer $token"
$web.Headers['X-IDAP-NATIVE-CLIENT'] = 'true'

# 2) Build a psPAS-like session object
$session = [pscustomobject]@{
    BaseURI            = "$($platformURLs.pvwaURL)/PasswordVault"
    ApiURI             = $($platformURLs.pvwaURL)
    User               = $Credentials.UserName
    ExternalVersion    = [version]'14.7.2'
    WebSession         = $web
    StartTime          = Get-Date
    ElapsedTime        = [TimeSpan]::Zero
    LastCommand        = $null
    LastCommandTime    = $null
    LastCommandResults = $null
    LastError          = $null
    LastErrorTime      = $null
}

# 3) Tag it with the PSTypeName that Use-PASSession expects
$session.PSObject.TypeNames.Insert(0, 'psPAS.CyberArk.Vault.Session')

$session.websession

# 4) pass token into psPAS
Use-PASSession -Session $session

# 5) Sanity check
Get-PASSession

# Run example command
Get-PASSafe -search "mike"
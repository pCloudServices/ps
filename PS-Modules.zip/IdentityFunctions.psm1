# Check if running user has sufficient permissions
Function Get-IdentityPermissions{
[CmdletBinding()]
[OutputType([String])]
Param
(
[string]$URLAPI,
[HashTable]$logonHeader
)
    Try
    {
        $resp = Invoke-RestMethod -Uri "$URLAPI/UserMgmt/GetUsersRolesAndAdministrativeRights" -Method Post -ContentType "application/json" -Headers $logonHeader -ErrorVariable identityErr
    }
    Catch
    {
        Write-LogMessage -Type Error -Msg "Error: $(Collect-ExceptionMessage $_.exception.message $($_.ErrorDetails.Message) $($_.exception.status) $($_.exception.Response.ResponseUri.AbsoluteUri) $identityErr)"
    }
    Return $resp.Result.Results.row.AdministrativeRights.Description
}


Function Get-IdentityURL($PortalURL) {
    Add-Type -AssemblyName System.Net.Http

    Function CreateHttpClient($allowAutoRedirect) {
        $handler = New-Object System.Net.Http.HttpClientHandler
        $handler.AllowAutoRedirect = $allowAutoRedirect
        return New-Object System.Net.Http.HttpClient($handler)
    }

    # Create HttpClient with auto-redirect allowed
    $client = CreateHttpClient($true)

    try {
        # Send a GET request to the URL
        $response = $client.GetAsync($PortalURL).Result

        # Check if the response status code indicates a redirection or success
        if (($response.StatusCode -ge 300 -and $response.StatusCode -lt 400) -or ($response.StatusCode -eq "OK")) {
            return $response.RequestMessage.RequestUri.Host
        }
        elseif ($response -eq $null) {
            # Dispose the initial client and create a new one with auto-redirect disabled
            $client.Dispose()
            $client = CreateHttpClient($false)

            $response = $client.GetAsync($PortalURL).Result
            return $response.Headers.Location.Host
        }
        else {
            Write-LogMessage -Type Error -Msg "Unexpected status code: $($response.StatusCode)"
        }
    }
    catch {
        Write-LogMessage -Type Error -Msg "Error: $($_.Exception.Message)"
    }
    finally {
        # Cleanup
        if ($response -ne $null) {
            $response.Dispose()
        }
        if ($client -ne $null) {
            $client.Dispose()
        }
    }
}

Function Write-IdentityStatus {
    Param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        [Parameter()]
        [ValidateSet("Muted", "Info", "Prompt", "Highlight", "Success", "Warning")]
        [string]$Style = "Info"
    )

    $ForegroundColor = "White"
    switch ($Style) {
        "Muted"     { $ForegroundColor = "DarkGray" }
        "Info"      { $ForegroundColor = "Gray" }
        "Prompt"    { $ForegroundColor = "Yellow" }
        "Highlight" { $ForegroundColor = "Cyan" }
        "Success"   { $ForegroundColor = "Green" }
        "Warning"   { $ForegroundColor = "Magenta" }
    }

    Write-Host $Message -ForegroundColor $ForegroundColor
}

Function Format-IdentityMechanismLine {
    Param(
        [Parameter(Mandatory = $true)]
        $AvailableMechanism,
        [Parameter()]
        [switch]$IncludeOptionNumber
    )

    $Mechanism = $AvailableMechanism.Mechanism
    $Parts = @()

    if ($IncludeOptionNumber) {
        $Parts += "$($AvailableMechanism.OptionNumber)."
    }

    $Parts += $Mechanism.Name

    if (-not [string]::IsNullOrWhiteSpace($Mechanism.PromptSelectMech)) {
        $Parts += "- $($Mechanism.PromptSelectMech)"
    }

    if (-not [string]::IsNullOrWhiteSpace($Mechanism.AnswerType)) {
        $Parts += "[$($Mechanism.AnswerType)]"
    }

    ($Parts -join " ")
}

Function Get-IdentityHeader {
    <#
    .SYNOPSIS
        Function to get Identity Header to enable running scripts using the token parameter. This will allow running the rest of the scripts in the directory for Identity Shared Services - Shared Services customers (ISPSS) (Privilege Cloud).
        Token created using Identity documentation https://docs.cyberark.com/Product-Doc/OnlineHelp/PrivCloud-SS/Latest/en/Content/WebServices/ISP-Auth-APIs.htm

    .DESCRIPTION
        This function starts by requesting authentication into identity APIs. Once the process starts there can be multiple challenges that need to be responded with multiple options.
        Each option is then being decided by the user. Once authentication is complete we get a token for the user to use for APIs within the ISPSS platform.

    .PARAMETER IdentityTenantURL
        The URL of the tenant. you can find it if you go to Identity Admin Portal > Settings > Customization > Tenant URL.

    .Parameter IdentityUserName
        The Username that will log into the system. It just needs the username, we will ask for PW, Push etc when doing the authentication.

    .Parameter PCloudSubdomain
        The Subdomain assigned to the privileged cloud environment.

    .Parameter psPASFormat
        Use this switch to output the token in a format that PSPas can consume directly.
    
    .Parameter UPCreds
        Use this switch to output the token in a format that PSPas can consume directly.

    #>
    [CmdletBinding(DefaultParameterSetName = 'IdentityUserName')]
    Param (
        [Parameter(
            Mandatory = $true,
            HelpMessage = "Identity Tenant URL")]
        [string]$IdentityTenantURL,
        [Parameter(
            ParameterSetName = "IdentityUserName",
            Mandatory = $true,
            HelpMessage = "User to authenticate into the platform")]
        [string]$IdentityUserName,
        [Parameter(
            Mandatory = $false,
            HelpMessage = "Identity Tenant ID")]
        [string]$IdentityTenantId,
        [Parameter(
            Mandatory = $false,
            HelpMessage = "Output header in a format for use with psPAS")]
        [switch]$psPASFormat,
        [Parameter(
            Mandatory = $false,
            HelpMessage = "Subdomain of the privileged cloud environment")]
        [Parameter(
            ParameterSetName = 'psPASFormat',
            Mandatory = $true,
            HelpMessage = "Subdomain of the privileged cloud environment")]
        [string]$PCloudSubdomain,
        [Parameter(
            ParameterSetName = 'UPCreds',
            Mandatory = $true,
            HelpMessage = "Credentials to pass if option is UP")]
        [pscredential]$UPCreds

    )
    $ScriptFullPath = Get-Location
    $LOG_FILE_PATH = "$ScriptFullPath\IdentityAuth.log"

    $InDebug = $PSBoundParameters.Debug.IsPresent
    $InVerbose = $PSBoundParameters.Verbose.IsPresent

    #Platform Identity API

    if ($IdentityTenantURL -match "https://") {
        $IdaptiveBasePlatformURL = $IdentityTenantURL
    } Else {
        $IdaptiveBasePlatformURL = "https://$IdentityTenantURL"
    }

    if ([string]::IsNullOrEmpty($IdentityTenantId)) {
        $IdentityTenantId = ([System.Uri]$IdaptiveBasePlatformURL).Host.Split(".")[0]
        Write-LogMessage -type "Verbose" -MSG "IdentityTenantId was not provided. Using derived value '$IdentityTenantId'"
    }

    $PCloudTenantAPIURL = "https://$PCloudSubdomain.privilegecloud.cyberark.cloud/PasswordVault/"

    Write-LogMessage -type "Verbose" -MSG "URL used : $($IdaptiveBasePlatformURL|ConvertTo-Json -Depth 9)"

    #Creating URLs

    $IdaptiveBasePlatformSecURL = "$IdaptiveBasePlatformURL/Security"
    $startPlatformAPIAuth = "$IdaptiveBasePlatformSecURL/StartAuthentication"
    $startPlatformAPIAdvancedAuth = "$IdaptiveBasePlatformSecURL/AdvanceAuthentication"
    $LogoffPlatform = "$IdaptiveBasePlatformSecURL/logout"

    #Creating the username/password variables
    if ('UPCreds' -eq $PSCmdlet.ParameterSetName) {
        $InUPCreds = $true
        $IdentityUserName = $UPCreds.UserName
    }
    $StartAuthenticationHeaders = @{
        "Content-Type"         = "application/json"
        "X-IDAP-NATIVE-CLIENT" = "true"
        OobIdPAuth             = "true"
    }
    $startPlatformAPIBody = @{TenantId = $IdentityTenantId; User = $IdentityUserName ; Version = "1.0" } | ConvertTo-Json -Compress -Depth 9
    Write-LogMessage -type "Verbose" -MSG "URL body : $($startPlatformAPIBody|ConvertTo-Json -Depth 9)"
    $IdaptiveResponse = Invoke-RestMethod -SessionVariable session -Uri $startPlatformAPIAuth -Method Post -ContentType "application/json" -Body $startPlatformAPIBody -TimeoutSec 30 -Headers $StartAuthenticationHeaders
    Write-LogMessage -type "Verbose" -MSG "IdaptiveResponse : $($IdaptiveResponse|ConvertTo-Json -Depth 9)"

    # We can use the following to give info to the customer $IdaptiveResponse.Result.Challenges.mechanisms

    $SessionId = $($IdaptiveResponse.Result.SessionId)
    Write-LogMessage -type "Verbose" -MSG "SessionId : $($SessionId |ConvertTo-Json -Depth 9)"

    IF (![string]::IsNullOrEmpty($IdaptiveResponse.Result.IdpRedirectShortUrl) -or ![string]::IsNullOrEmpty($IdaptiveResponse.Result.IdpLoginSessionId)) {
        $AnswerToResponse = Invoke-ExternalIdPChallenge -IdaptiveResponse $IdaptiveResponse -IdentityTenantId $IdentityTenantId -StartPlatformAPIAdvancedAuth $startPlatformAPIAdvancedAuth -WebSession $session
    } elseif (![string]::IsNullOrEmpty($IdaptiveResponse.Result.IdpRedirectUrl)) {
        IF ([string]::IsNullOrEmpty($PCloudSubdomain)) {
            $PCloudSubdomain = Read-Host -Prompt "The Privilege Cloud Subdomain is required when using SAML. Please enter it"
        }
        $OriginalProgressPreference = $Global:ProgressPreference
        $Global:ProgressPreference = 'SilentlyContinue'
        IF (Test-NetConnection -InformationLevel Quiet -Port 443 "$PCloudSubdomain.privilegecloud.cyberark.cloud") {
            $PCloudTenantAPIURL = "https://$PCloudSubdomain.privilegecloud.cyberark.cloud/PasswordVault/"
            $Global:ProgressPreference = $OriginalProgressPreference
        } else {
            $Global:ProgressPreference = $OriginalProgressPreference
            Write-LogMessage -type Error -MSG "Error during subdomain validation: Unable to contact https://$PCloudSubdomain.privilegecloud.cyberark.cloud"
            exit
        }
        $AnswerToResponse = Invoke-SAMLLogon $IdaptiveResponse
    } else {
        $AnswerToResponse = Invoke-Challenge -IdaptiveResponse $IdaptiveResponse -IdentityTenantId $IdentityTenantId -StartPlatformAPIAdvancedAuth $startPlatformAPIAdvancedAuth -InUPCreds:$InUPCreds -UPCreds $UPCreds
    }

    If ($AnswerToResponse.success -and -not [string]::IsNullOrWhiteSpace($AnswerToResponse.Result.Token)) {
        #Creating Header
        If (!$psPASFormat) {
            $IdentityHeaders = @{Authorization = "Bearer $($AnswerToResponse.Result.Token)" }
            $IdentityHeaders.Add("X-IDAP-NATIVE-CLIENT", "true")
        } else {
            $ExternalVersion = Get-PCloudExternalVersion -PCloudTenantAPIURL $PCloudTenantAPIURL -Token $AnswerToResponse.Result.Token
            $header = New-Object System.Collections.Generic.Dictionary"[String,string]"
            $header.add("Authorization", "Bearer $($AnswerToResponse.Result.Token)")
            $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
            $session.Headers = $header
            $IdentityHeaders = [PSCustomObject]@{
                User            = $IdentityUserName
                BaseURI         = $PCloudTenantAPIURL
                ExternalVersion = $ExternalVersion
                WebSession      = $session
            }
            $IdentityHeaders.PSObject.TypeNames.Insert(0, 'psPAS.CyberArk.Vault.Session')
        }
        Write-LogMessage -type "Verbose" -MSG "IdentityHeaders - $($IdentityHeaders |ConvertTo-Json)"
        Write-IdentityStatus -Style Success -Message "Identity token set successfully."
        Write-LogMessage -type "Verbose" -MSG "Identity Token Set Successfully"
        return $identityHeaders
    }
    elseif ($AnswerToResponse.success -and [string]::IsNullOrWhiteSpace($AnswerToResponse.Result.Token)) {
        Write-LogMessage -type Error -MSG "Authentication response reported success but no token was returned. Additional challenge may still be required."
    }
    else 
    {
        Write-LogMessage -type "Verbose" -MSG "identityHeaders: $($AnswerToResponse | ConvertTo-Json -Depth 9)"
        Write-LogMessage -type Error -MSG "Error during logon : $($AnswerToResponse.Message)"
    }
}

Function Invoke-Challenge {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $true)]
        [array]$IdaptiveResponse,

        [Parameter(Mandatory = $true)]
        [string]$IdentityTenantId,

        [Parameter(Mandatory = $true)]
        [string]$StartPlatformAPIAdvancedAuth,

        [Parameter()]
        [switch]$InUPCreds,

        [Parameter()]
        [pscredential]$UPCreds
    )

    $CurrentResponse = $IdaptiveResponse
    $InitialMechanisms = @($IdaptiveResponse.Result.Challenges.mechanisms) | Where-Object {
        $null -ne $_ -and
        -not [string]::IsNullOrWhiteSpace($_.MechanismId) -and
        (
            -not [string]::IsNullOrWhiteSpace($_.Name) -or
            -not [string]::IsNullOrWhiteSpace($_.AnswerType)
        )
    }

    # Preserve original SessionId for the whole auth flow
    $SessionId = $IdaptiveResponse.Result.SessionId

    if ([string]::IsNullOrWhiteSpace($SessionId)) {
        throw "StartAuthentication did not return a valid SessionId."
    }

    $UsedMechanismIds = New-Object System.Collections.Generic.HashSet[string]
    $j = 1

    while ($null -ne $CurrentResponse) {

        if ($CurrentResponse.Success -and ![string]::IsNullOrEmpty($CurrentResponse.Result.Token)) {
            return $CurrentResponse
        }

        # Keep original SessionId if current response does not include one
        if (-not [string]::IsNullOrWhiteSpace($CurrentResponse.Result.SessionId)) {
            $SessionId = $CurrentResponse.Result.SessionId
        }

        $Challenges = @($CurrentResponse.Result.Challenges)
        $Mechanism = $null
        $AvailableMechanisms = @()

        if ($Challenges.Count -eq 0) {
            return $CurrentResponse
        }

        $ChallengeIndex = 1
        foreach ($Challenge in $Challenges) {
            $Mechanisms = @($Challenge.mechanisms) | Where-Object {
                $null -ne $_ -and
                -not [string]::IsNullOrWhiteSpace($_.MechanismId) -and
                (
                    -not [string]::IsNullOrWhiteSpace($_.Name) -or
                    -not [string]::IsNullOrWhiteSpace($_.AnswerType)
                )
            }
            foreach ($MechanismsOption in $Mechanisms) {
                $AvailableMechanisms += [PSCustomObject]@{
                    ChallengeNumber = $ChallengeIndex
                    Mechanism       = $MechanismsOption
                }
            }

            $ChallengeIndex++
        }

        if ($AvailableMechanisms.Count -eq 0) {
            $AvailableMechanisms = @(
                $InitialMechanisms |
                Where-Object { -not $UsedMechanismIds.Contains($_.MechanismId) } |
                ForEach-Object {
                    [PSCustomObject]@{
                        ChallengeNumber = "Original"
                        Mechanism       = $_
                    }
                }
            )

            if ($AvailableMechanisms.Count -gt 0) {
                Write-LogMessage -type "Verbose" -MSG "CurrentResponse returned no usable mechanisms. Falling back to unused mechanisms from StartAuthentication."
            }
            else {
                Write-LogMessage -type "Verbose" -MSG "CurrentResponse returned challenges but no usable mechanisms: $($CurrentResponse | ConvertTo-Json -Depth 9)"
                return $CurrentResponse
            }
        }

        if ($InUPCreds) {
            $Mechanism = ($AvailableMechanisms | Where-Object {
                $_.Mechanism.Name -eq "UP" -and $_.Mechanism.AnswerType -eq "Text"
            } | Select-Object -First 1).Mechanism
        }

        if (-not $Mechanism -and $AvailableMechanisms.Count -eq 1) {
            $Mechanism = $AvailableMechanisms[0].Mechanism
        }

        if (-not $Mechanism) {
            Write-Host ""
            Write-IdentityStatus -Style Highlight -Message "Available authentication options"
            $i = 1
            foreach ($AvailableMechanism in $AvailableMechanisms) {
                $AvailableMechanism | Add-Member -NotePropertyName OptionNumber -NotePropertyValue $i -Force
                Write-IdentityStatus -Style Highlight -Message ("  " + (Format-IdentityMechanismLine -AvailableMechanism $AvailableMechanism -IncludeOptionNumber))
                $i++
            }

            $Option = $null
            while ($Option -gt $AvailableMechanisms.Count -or $Option -lt 1 -or $null -eq $Option) {
                $Option = Read-Host "Select an option (1-$($AvailableMechanisms.Count))"
                try {
                    $Option = [int]$Option
                }
                catch {
                    $Option = $null
                    Write-LogMessage -Type Error -MSG $_.Exception.Message
                }
            }

            $Mechanism = $AvailableMechanisms[$Option - 1].Mechanism
        }

        if (-not $Mechanism) {
            return $CurrentResponse
        }

        if ($Mechanism.Name -ne "UP") {
            Write-IdentityStatus -Style Muted -Message ("Selected: {0}" -f $Mechanism.Name)
        }

        [void]$UsedMechanismIds.Add($Mechanism.MechanismId)

        $CurrentResponse = Invoke-AdvancedAuthBody `
            -SessionId $SessionId `
            -Mechanism $Mechanism `
            -IdentityTenantId $IdentityTenantId `
            -StartPlatformAPIAdvancedAuth $StartPlatformAPIAdvancedAuth `
            -InUPCreds:$InUPCreds `
            -UPCreds $UPCreds

        Write-LogMessage -type "Verbose" -MSG "AnswerToResponse - $($CurrentResponse | ConvertTo-Json -Depth 9)"
        $j++
    }

    return $CurrentResponse
}

#Runs an advanceAuth API. It will wait in the loop if needed
Function Invoke-AdvancedAuthBody {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $true, HelpMessage = "Session ID of the mechanism")]
        [string]$SessionId,

        [Parameter(Mandatory = $true, HelpMessage = "Mechanism of Authentication")]
        $Mechanism,

        [Parameter(Mandatory = $false, HelpMessage = "Tenant ID")]
        [string]$IdentityTenantId,

        [Parameter(Mandatory = $true)]
        [string]$StartPlatformAPIAdvancedAuth,

        [Parameter()]
        [switch]$InUPCreds,

        [Parameter()]
        [pscredential]$UPCreds
    )

    if ([string]::IsNullOrWhiteSpace($SessionId)) {
        throw "Invoke-AdvancedAuthBody received an empty SessionId."
    }

    if ($null -eq $Mechanism -or [string]::IsNullOrWhiteSpace($Mechanism.MechanismId)) {
        throw "Invoke-AdvancedAuthBody received a null or invalid mechanism."
    }

    $MaskList = @("UP")
    $MechanismId = $Mechanism.MechanismId

    if ($Mechanism.AnswerType -eq "StartTextOob") {

        $startPlatformAPIAdvancedAuthBody = @{
            TenantID    = $IdentityTenantId
            SessionId   = $SessionId
            MechanismId = $MechanismId
            Action      = "StartOOB"
        } | ConvertTo-Json -Compress

        Write-LogMessage -type "Verbose" -MSG "startPlatformAPIAdvancedAuthBody: $($startPlatformAPIAdvancedAuthBody | ConvertTo-Json -Depth 9)"

        try {
            $AnswerToResponse = Invoke-RestMethod `
                -Uri $StartPlatformAPIAdvancedAuth `
                -Method Post `
                -ContentType "application/json" `
                -Body $startPlatformAPIAdvancedAuthBody `
                -TimeoutSec 30

            Write-LogMessage -type "Verbose" -MSG "AnswerToResponse: $($AnswerToResponse | ConvertTo-Json -Depth 9)"
        }
        catch {
            Write-LogMessage -Type Error -MSG $_.ErrorDetails.Message
            return
        }

        # Special handling for Google Authenticator / OATH:
        # same mechanism gets StartOOB first, then Answer with OTP
        if ($Mechanism.Name -eq "OATH") {
            $OtpValue = $null
            while ([string]::IsNullOrWhiteSpace($OtpValue)) {
                Write-Host ""
                $OtpValue = Read-Host "Enter the Google Authenticator code"
            }

            $answerBody = @{
                TenantID    = $IdentityTenantId
                SessionId   = $SessionId
                MechanismId = $MechanismId
                Action      = "Answer"
                Answer      = $OtpValue.Trim()
            } | ConvertTo-Json -Compress

            Write-LogMessage -type "Verbose" -MSG "answerBody: $($answerBody | ConvertTo-Json -Depth 9)" -maskAnswer

            try {
                $AnswerToResponse = Invoke-RestMethod `
                    -Uri $StartPlatformAPIAdvancedAuth `
                    -Method Post `
                    -ContentType "application/json" `
                    -Body $answerBody `
                    -TimeoutSec 30

                Write-LogMessage -type "Verbose" -MSG "AnswerToResponse: $($AnswerToResponse | ConvertTo-Json -Depth 9)"
            }
            catch {
                Write-LogMessage -Type Error -MSG $_.ErrorDetails.Message
            }

            return $AnswerToResponse
        }

        if ($Mechanism.Name -eq "OTP" -and -not [string]::IsNullOrWhiteSpace($AnswerToResponse.Result.GeneratedAuthValue)) {
            Write-Host ""
            Write-IdentityStatus -Style Warning -Message "Approve the sign-in in Mobile Authenticator using number: $($AnswerToResponse.Result.GeneratedAuthValue)"
        }

        Write-IdentityStatus -Style Muted -Message "Waiting for approval..."

        while ($AnswerToResponse.Result.Summary -in @("OobPending", "PendingOOB", "Pending")) {
            Start-Sleep -Seconds 2

            $pollBody = @{
                TenantID    = $IdentityTenantId
                SessionId   = $SessionId
                MechanismId = $MechanismId
                Action      = "Poll"
            } | ConvertTo-Json -Compress

            Write-LogMessage -type "Verbose" -MSG "pollBody: $($pollBody | ConvertTo-Json -Depth 9)"

            $AnswerToResponse = Invoke-RestMethod `
                -Uri $StartPlatformAPIAdvancedAuth `
                -Method Post `
                -ContentType "application/json" `
                -Body $pollBody `
                -TimeoutSec 30

            Write-LogMessage -type "Verbose" -MSG "AnswerToResponse: $($AnswerToResponse | ConvertTo-Json -Depth 9)"
            Write-LogMessage -type "Info" -MSG "$($AnswerToResponse.Result.Summary)"
        }

        return $AnswerToResponse
    }

    if ($Mechanism.AnswerType -eq "Text") {
        if (($Mechanism.Name -eq "UP") -and $InUPCreds -and $null -ne $UPCreds) {
            Write-IdentityStatus -Style Muted -Message "Using stored credentials."
            $SecureAnswer = $UPCreds.Password
        }
        else {
            $Prompt = "Please enter the answer from the challenge type"
            if ($Mechanism.Name -eq "UP") {
                $Prompt = "Please enter your password"
            }
            $SecureAnswer = Read-Host $Prompt -AsSecureString
        }

        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureAnswer)
        try {
            $PlainAnswer = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
        }
        finally {
            if ($BSTR -ne [IntPtr]::Zero) {
                [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
            }
        }

        $startPlatformAPIAdvancedAuthBody = @{
            TenantID    = $IdentityTenantId
            SessionId   = $SessionId
            MechanismId = $MechanismId
            Action      = "Answer"
            Answer      = $PlainAnswer
        } | ConvertTo-Json -Compress

        if ($Mechanism.Name -in $MaskList) {
            Write-LogMessage -type "Verbose" -MSG "startPlatformAPIAdvancedAuthBody: $($startPlatformAPIAdvancedAuthBody | ConvertTo-Json -Depth 9)" -maskAnswer
        }
        else {
            Write-LogMessage -type "Verbose" -MSG "startPlatformAPIAdvancedAuthBody: $($startPlatformAPIAdvancedAuthBody | ConvertTo-Json -Depth 9)"
        }

        try {
            $AnswerToResponse = Invoke-RestMethod `
                -Uri $StartPlatformAPIAdvancedAuth `
                -Method Post `
                -ContentType "application/json" `
                -Body $startPlatformAPIAdvancedAuthBody `
                -TimeoutSec 30

            Write-LogMessage -type "Verbose" -MSG "AnswerToResponse: $($AnswerToResponse | ConvertTo-Json -Depth 9)"
        }
        catch {
            Write-LogMessage -Type Error -MSG $_.ErrorDetails.Message
        }

        return $AnswerToResponse
    }

    throw "Unsupported mechanism type '$($Mechanism.AnswerType)' for mechanism '$($Mechanism.Name)'."
}

Function Invoke-ExternalIdPChallenge {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [array]$IdaptiveResponse,
        [Parameter(Mandatory = $true)]
        [string]$IdentityTenantId,
        [Parameter(Mandatory = $true)]
        [string]$StartPlatformAPIAdvancedAuth,
        [Parameter()]
        $WebSession
    )

    $IdpRedirectShortUrl = $IdaptiveResponse.Result.IdpRedirectShortUrl
    $IdpLoginSessionId = $IdaptiveResponse.Result.IdpLoginSessionId

    if ([string]::IsNullOrEmpty($IdpRedirectShortUrl)) {
        throw "URL redirect from Identity is empty, nothing to browse to."
    }

    Write-LogMessage -type "Info" -MSG "Opening external IdP authentication page"
    try {
        Start-Process $IdpRedirectShortUrl | Out-Null
    } catch {
        Write-LogMessage -Type Error -MSG "Unable to launch browser automatically. Open this URL manually: $IdpRedirectShortUrl"
    }

    $PinCode = $null
    while ([string]::IsNullOrWhiteSpace($PinCode)) {
        $InputValue = Read-Host -Prompt "Please provide PIN code"
        $InputValue = $InputValue.Trim()

        if ($InputValue -match '^\d+$') {
            $PinCode = $InputValue
        } else {
            Write-Host "Invalid input. Please enter numbers only." -ForegroundColor Red
        }
    }

    $PinBodyReply = @{ TenantId = $IdentityTenantId; SessionId = $IdpLoginSessionId; MechanismId = "OOBAUTHPIN"; Action = "Answer"; Answer = $PinCode } | ConvertTo-Json -Depth 9 -Compress
    Write-LogMessage -type "Verbose" -MSG "PinBodyReply: $($PinBodyReply|ConvertTo-Json -Depth 9)" -maskAnswer
    $PinResponse = Invoke-RestMethod -Uri $StartPlatformAPIAdvancedAuth -Method Post -ContentType "application/json" -Body $PinBodyReply -TimeoutSec 30
    Write-LogMessage -type "Verbose" -MSG "PinResponse: $($PinResponse|ConvertTo-Json -Depth 9)"

    return $PinResponse
}

function Get-PCloudExternalVersion {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $PCloudTenantApiUrl,
        [Parameter(Mandatory = $true)]
        $Token
    )

    $ExternalVersion = "12.6.0"
    try {
        $Headers = @{
            Authorization = "Bearer $Token"
        }
        $Response = Invoke-RestMethod -Method GET -Uri "$PCloudTenantApiUrl/WebServices/PIMServices.svc/Server" -Headers $Headers -ContentType 'application/json'
        $ExternalVersion = $Response.ExternalVersion
    } catch {
        Write-LogMessage -Type Error -MSG $_.ErrorDetails.Message
    }

    $ExternalVersion
}


function Invoke-SAMLLogon {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [Array] $IdaptiveResponse
    )

    Begin {

        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Web

        #Special thanks to Shay Tevet for his assistance on this section
        $source = @"
using System;
using System.Runtime.InteropServices;
using System.Text;
namespace Cookies
{
    public static class getter
    {
       [DllImport("wininet.dll", CharSet=CharSet.None, ExactSpelling=false, SetLastError=true)]
        public static extern bool InternetGetCookieEx(string url, string cookieName, StringBuilder cookieData, ref int size, int dwFlags, IntPtr lpReserved);

	public static string GetUriCookieContainer(String uri)
        {
            string str;
            try
            {
                int num = 131072;
                StringBuilder stringBuilder = new StringBuilder(num);
                if (!InternetGetCookieEx(uri, null, stringBuilder, ref num, 8192, IntPtr.Zero))
                {
                        str = null;
                        return str;
                }
                str = (!stringBuilder.ToString().Contains("idToken-") ? "Error" : stringBuilder.ToString().Split(new string[] { "idToken-" }, StringSplitOptions.None)[1].Split(new char[] { ';' })[0].Split(new char[] { '=' })[1]);
            }
            catch
            {
                str = "Error";
            }
            return str;
        }
    }
}
"@

        $compilerParameters = New-Object System.CodeDom.Compiler.CompilerParameters
        $compilerParameters.CompilerOptions = "/unsafe"

        Add-Type -TypeDefinition $source -Language CSharp -CompilerParameters $compilerParameters

        $PCloudURL = "https://$PCloudSubdomain.cyberark.cloud"
        $PCloudPortalURL = "$PCloudURL/privilegecloud/"
        $logonURL = "$IdaptiveBasePlatformURL/login?redirectUrl=https%3A%2F%2F$PCloudSubdomain.cyberark.cloud%2Fprivilegecloud&username=$IdentityUserName&iwa=false&iwaSsl=false"

    }

    Process {
        $DocComp = {

            if ($web.Url.AbsoluteUri -like "*/privilegecloud" -and $web.document.Cookie -like "*loggedIn-*") {
                $Global:Auth = [cookies.getter]::GetUriCookieContainer("$PCloudURL").ToString()
                $form.Close()
            }
        }


        # create window for embedded browser
        $form = New-Object Windows.Forms.Form
        $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
        $form.Width = 640
        $form.Height = 700
        $form.showIcon = $false
        $form.TopMost = $false
        $form.Text = "SAML Based Authentication"

        $web = New-Object Windows.Forms.WebBrowser
        $web.Size = $form.ClientSize
        $web.Anchor = "Left,Top,Right,Bottom"
        $web.ScriptErrorsSuppressed = $false
        $web.AllowWebBrowserDrop = $false
        $web.IsWebBrowserContextMenuEnabled = $true
        $web.Add_DocumentCompleted($DocComp)
        $form.Controls.Add($web)

        $web.Navigate(("$logonURL"))

        # show browser window, waits for window to close
        if ([system.windows.forms.application]::run($form) -ne "OK") {

            if ($null -ne $auth) {
                [PSCustomObject]$Return = @{
                    Success = $true
                    Result  = @{
                        Token = $auth
                    }
                }
                return $Return
                $form.Close()
            } Else {
                throw "Unable to get auth token"
            }
        }

        End {
            $form.Dispose()
        }
    }
}
# SIG # Begin signature block
# MIIpLQYJKoZIhvcNAQcCoIIpHjCCKRoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDw1brdQW6fz+oZ
# MZOcd8XOY2k3OyFPPI5XoyubNGxTgaCCDq8wggboMIIE0KADAgECAhB3vQ4Ft1kL
# th1HYVMeP3XtMA0GCSqGSIb3DQEBCwUAMFMxCzAJBgNVBAYTAkJFMRkwFwYDVQQK
# ExBHbG9iYWxTaWduIG52LXNhMSkwJwYDVQQDEyBHbG9iYWxTaWduIENvZGUgU2ln
# bmluZyBSb290IFI0NTAeFw0yMDA3MjgwMDAwMDBaFw0zMDA3MjgwMDAwMDBaMFwx
# CzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMTIwMAYDVQQD
# EylHbG9iYWxTaWduIEdDQyBSNDUgRVYgQ29kZVNpZ25pbmcgQ0EgMjAyMDCCAiIw
# DQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMsg75ceuQEyQ6BbqYoj/SBerjgS
# i8os1P9B2BpV1BlTt/2jF+d6OVzA984Ro/ml7QH6tbqT76+T3PjisxlMg7BKRFAE
# eIQQaqTWlpCOgfh8qy+1o1cz0lh7lA5tD6WRJiqzg09ysYp7ZJLQ8LRVX5YLEeWa
# tSyyEc8lG31RK5gfSaNf+BOeNbgDAtqkEy+FSu/EL3AOwdTMMxLsvUCV0xHK5s2z
# BZzIU+tS13hMUQGSgt4T8weOdLqEgJ/SpBUO6K/r94n233Hw0b6nskEzIHXMsdXt
# HQcZxOsmd/KrbReTSam35sOQnMa47MzJe5pexcUkk2NvfhCLYc+YVaMkoog28vmf
# vpMusgafJsAMAVYS4bKKnw4e3JiLLs/a4ok0ph8moKiueG3soYgVPMLq7rfYrWGl
# r3A2onmO3A1zwPHkLKuU7FgGOTZI1jta6CLOdA6vLPEV2tG0leis1Ult5a/dm2tj
# IF2OfjuyQ9hiOpTlzbSYszcZJBJyc6sEsAnchebUIgTvQCodLm3HadNutwFsDeCX
# pxbmJouI9wNEhl9iZ0y1pzeoVdwDNoxuz202JvEOj7A9ccDhMqeC5LYyAjIwfLWT
# yCH9PIjmaWP47nXJi8Kr77o6/elev7YR8b7wPcoyPm593g9+m5XEEofnGrhO7izB
# 36Fl6CSDySrC/blTAgMBAAGjggGtMIIBqTAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0l
# BAwwCgYIKwYBBQUHAwMwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUJZ3Q
# /FkJhmPF7POxEztXHAOSNhEwHwYDVR0jBBgwFoAUHwC/RoAK/Hg5t6W0Q9lWULvO
# ljswgZMGCCsGAQUFBwEBBIGGMIGDMDkGCCsGAQUFBzABhi1odHRwOi8vb2NzcC5n
# bG9iYWxzaWduLmNvbS9jb2Rlc2lnbmluZ3Jvb3RyNDUwRgYIKwYBBQUHMAKGOmh0
# dHA6Ly9zZWN1cmUuZ2xvYmFsc2lnbi5jb20vY2FjZXJ0L2NvZGVzaWduaW5ncm9v
# dHI0NS5jcnQwQQYDVR0fBDowODA2oDSgMoYwaHR0cDovL2NybC5nbG9iYWxzaWdu
# LmNvbS9jb2Rlc2lnbmluZ3Jvb3RyNDUuY3JsMFUGA1UdIAROMEwwQQYJKwYBBAGg
# MgECMDQwMgYIKwYBBQUHAgEWJmh0dHBzOi8vd3d3Lmdsb2JhbHNpZ24uY29tL3Jl
# cG9zaXRvcnkvMAcGBWeBDAEDMA0GCSqGSIb3DQEBCwUAA4ICAQAldaAJyTm6t6E5
# iS8Yn6vW6x1L6JR8DQdomxyd73G2F2prAk+zP4ZFh8xlm0zjWAYCImbVYQLFY4/U
# ovG2XiULd5bpzXFAM4gp7O7zom28TbU+BkvJczPKCBQtPUzosLp1pnQtpFg6bBNJ
# +KUVChSWhbFqaDQlQq+WVvQQ+iR98StywRbha+vmqZjHPlr00Bid/XSXhndGKj0j
# fShziq7vKxuav2xTpxSePIdxwF6OyPvTKpIz6ldNXgdeysEYrIEtGiH6bs+XYXvf
# cXo6ymP31TBENzL+u0OF3Lr8psozGSt3bdvLBfB+X3Uuora/Nao2Y8nOZNm9/Lws
# 80lWAMgSK8YnuzevV+/Ezx4pxPTiLc4qYc9X7fUKQOL1GNYe6ZAvytOHX5OKSBoR
# HeU3hZ8uZmKaXoFOlaxVV0PcU4slfjxhD4oLuvU/pteO9wRWXiG7n9dqcYC/lt5y
# A9jYIivzJxZPOOhRQAyuku++PX33gMZMNleElaeEFUgwDlInCI2Oor0ixxnJpsoO
# qHo222q6YV8RJJWk4o5o7hmpSZle0LQ0vdb5QMcQlzFSOTUpEYck08T7qWPLd0jV
# +mL8JOAEek7Q5G7ezp44UCb0IXFl1wkl1MkHAHq4x/N36MXU4lXQ0x72f1LiSY25
# EXIMiEQmM2YBRN/kMw4h3mKJSAfa9TCCB78wggWnoAMCAQICDFvWkQMw/ZfAZpUM
# wDANBgkqhkiG9w0BAQsFADBcMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFs
# U2lnbiBudi1zYTEyMDAGA1UEAxMpR2xvYmFsU2lnbiBHQ0MgUjQ1IEVWIENvZGVT
# aWduaW5nIENBIDIwMjAwHhcNMjYwMzAyMjE1MjMzWhcNMjcwMjI3MTM0MDU2WjCC
# AQQxHTAbBgNVBA8MFFByaXZhdGUgT3JnYW5pemF0aW9uMRIwEAYDVQQFEwk1MTIy
# OTE2NDIxEzARBgsrBgEEAYI3PAIBAxMCSUwxCzAJBgNVBAYTAklMMRkwFwYDVQQI
# ExBDZW50cmFsIERpc3RyaWN0MRQwEgYDVQQHEwtQZXRhaCBUaWt2YTEXMBUGA1UE
# CRMOOSBIYXBzYWdvdCBTdC4xHzAdBgNVBAoTFkN5YmVyQXJrIFNvZnR3YXJlIEx0
# ZC4xHzAdBgNVBAMTFkN5YmVyQXJrIFNvZnR3YXJlIEx0ZC4xITAfBgkqhkiG9w0B
# CQEWEmFkbWluQGN5YmVyYXJrLmNvbTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCC
# AgoCggIBAKtAr5PeV7TdJZDWUNp8j60tepBmgC2+9Dw8tUh+RsLhqaSNi0dUc7i9
# yznveSdnfE4l2U8ZXyEILjQsSJw3SaPaXMSOzR4wVnuTc1nTzKBOS3oa6Yil7rlu
# gNXVj8dmEEehcPuAkF4ciqt6YChi5a6DD/r8GYuHv+/75XDZCD1nTPesDLIN+RAU
# aqHWLF0XRDXwF/JgB6W+lzIuYeiXdM/jPxZqvg1d7WKZQCy0maucWE/n4N4/8nPT
# qLm3y8jhUdP6YGUlyJLbC4fxbVW1KrhDMY1DOOtItuBiOeBVAvVctbw/kAvEc32Y
# Iz3qIWTmcR0VzVVV6IlNWOrMqJZEvtHlqRVkekLJXB5pVw6b3PuelU92cb+VtUnB
# hewMxSkPj8094wN7urFk7wXxVtNVTYtkmT5ThcphO5Sha1bCfTgymePAfUJW2p2o
# FdNBDeMoSmVlTDDlffRpyMzFZpHpc6v0HzeLmkEcZk+HRf5dgeRMQZWt/Mgsizwe
# w0RuaCeQlphX7RgBRkC9rT57RCcBMtW3blk4Vz6qncCKCLBCJK1CIrC2frGX7vqt
# In+0zR1K0ec8tTH5im5QEE72MuMV+/4KbP+ISojaQ8JFZvqESxyAUbjpQcE2pfzv
# fwKiSXTyOCv9buuHDViUhoSc9oEKA3iuhc8Yz21F4CO0MTj014+FAgMBAAGjggHV
# MIIB0TAOBgNVHQ8BAf8EBAMCB4AwgZ8GCCsGAQUFBwEBBIGSMIGPMEwGCCsGAQUF
# BzAChkBodHRwOi8vc2VjdXJlLmdsb2JhbHNpZ24uY29tL2NhY2VydC9nc2djY3I0
# NWV2Y29kZXNpZ25jYTIwMjAuY3J0MD8GCCsGAQUFBzABhjNodHRwOi8vb2NzcC5n
# bG9iYWxzaWduLmNvbS9nc2djY3I0NWV2Y29kZXNpZ25jYTIwMjAwVQYDVR0gBE4w
# TDBBBgkrBgEEAaAyAQIwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93d3cuZ2xvYmFs
# c2lnbi5jb20vcmVwb3NpdG9yeS8wBwYFZ4EMAQMwCQYDVR0TBAIwADBHBgNVHR8E
# QDA+MDygOqA4hjZodHRwOi8vY3JsLmdsb2JhbHNpZ24uY29tL2dzZ2NjcjQ1ZXZj
# b2Rlc2lnbmNhMjAyMC5jcmwwHQYDVR0RBBYwFIESYWRtaW5AY3liZXJhcmsuY29t
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMB8GA1UdIwQYMBaAFCWd0PxZCYZjxezzsRM7
# VxwDkjYRMB0GA1UdDgQWBBR/nObXnnoINvefWdWmW4iZSqmPAjANBgkqhkiG9w0B
# AQsFAAOCAgEAvpUZ9sMYv3kb7+v5CzJoUgOAtOF21kKgzqrgRmwH/xyuXkhs+tY9
# LCE3ldhZmAJIfgBKZuKUQL5eFmLHltBevBKfgmfaT6uoG0sJ3QyNu46m2hMr/gvm
# Kms2zfFGOZxG8wHeZUQ1v8imN80Frvvy1DIdA1QOW4hIJvt1GbCaS6TTC3eO9/fO
# r22hHk0IBt+LtmSeA/rdFsnwT4Y4SY4mebZZePHH9c+KreM64DAP61rLodKQCw14
# jbPTlQRSelbJpb+Vmo7q1sieuCY5US2KsXG/4P/ENEJFnwH+ib671IjN7L4AISzt
# BoKY81CNMBSziqMpdCwrAiXBQhBHdKUG28MhrxS1gB564h+fo9tMrV5pe6Jp60Sa
# Wn5aQzu/nWR6z+gUR9mk5SdjBow+Liykxd/2o5wT8AmJ6XE/vGd7lK8MnuoTeJ65
# WQOsMd7MyB4tP3CV9/r+JESfPExxK3ybfWp1cAigtzpGII2fUM0sx43Wd7w0Ugfp
# OjmGOUKpshp6zJAqG+NNbupqk5vHAiddvHHRrZGLF7qbc0jcdQyxygyxQLe5Quu3
# M/bZ5+b4T+4xT/b0hmU4WmiHV8h3OF6U6OvIU2+gJ8NtRSkl+Jz/nhhU5hhNh2Ad
# TB108wYNMYET2xxoxtEPL5Sb0rX07I4lEGPpbwAcP1jds2+pgeB1pYcxghnUMIIZ
# 0AIBATBsMFwxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNh
# MTIwMAYDVQQDEylHbG9iYWxTaWduIEdDQyBSNDUgRVYgQ29kZVNpZ25pbmcgQ0Eg
# MjAyMAIMW9aRAzD9l8BmlQzAMA0GCWCGSAFlAwQCAQUAoHwwEAYKKwYBBAGCNwIB
# DDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIM+/ik9RcF+6fNQSzw5bmHAs
# EiI8f/9l4c+KKKaJffbBMA0GCSqGSIb3DQEBAQUABIICAHL8U3tsDS+BMaiicELU
# y7/DVxftUJ6G2Jb9jFg5RXD6grICM4fcoLx2X1PeUMaG0xzJe94hjjf1anYWp7sV
# NtCyyMg+1y/6EfRs7Bf/ybcAF7wI1gDJuiM/WXvtlaa7Du9tjjwC4z0v5hC2DSgT
# RDDB+BGmn9P4mc9Pqyo4WY3h075Nt0hIp8aewYnxenCdfFbyfJnm00WGVOVNCpBN
# euA+oXvo9QjXG6qX9kUPoTjNvLEDyV6pexYRaUjtodMWTcMFg8IFYMpz57utQgSx
# wz3Km+zEZH9QspPs5P+34HkDwHZk3Fyv31KFqb4483UsYcVRE5bwMJojIcqsAWg2
# TbvT3xEEgp2Gw6+RN2XQKrpW2EWhnnsyZIPknt7FqN7NWixIH9572lwIAQLi/6ru
# yWmpD0SVSNS7PrLiNxAJs3fF1udLzptjwRyTcITmRif1uJo8tT2fpxBCL/d3Yp4h
# ewmjOlHrmVJnMWOTzDw93qnGGvA1JTZo8jIyA5pM1btQjzL8SZ+IoKXya5tbsTbF
# PijX+NRh92EhyR2qjEWr5k/roZNEJySMkRf1BLMcLLRdlXB2MnrTK+LfvLin/G6w
# ztn18FcELTXN10EFnASNAIZy7/cpAKGjoxup0a/oZ9kNiWmRJlBuO+kAuhNy5Ib8
# nEi0/ghTZXNos0EvXMO/1RdaoYIWuzCCFrcGCisGAQQBgjcDAwExghanMIIWowYJ
# KoZIhvcNAQcCoIIWlDCCFpACAQMxDTALBglghkgBZQMEAgEwgd8GCyqGSIb3DQEJ
# EAEEoIHPBIHMMIHJAgEBBgsrBgEEAaAyAgMBAjAxMA0GCWCGSAFlAwQCAQUABCA4
# Z6Cdm98Nbw66CMIfJz2YjMwlmUB4RxCG+HkFEWwpPAIUPIWlwx/YGWmjFZV0y01z
# RFEKytcYDzIwMjYwMzI2MTkyMzUyWjADAgEBoFikVjBUMQswCQYDVQQGEwJCRTEZ
# MBcGA1UECgwQR2xvYmFsU2lnbiBudi1zYTEqMCgGA1UEAwwhR2xvYmFsc2lnbiBU
# U0EgZm9yIENvZGVTaWduMSAtIFI2oIISSzCCBmMwggRLoAMCAQICEAEACyAFs5QH
# Yts+NnmUm6kwDQYJKoZIhvcNAQEMBQAwWzELMAkGA1UEBhMCQkUxGTAXBgNVBAoT
# EEdsb2JhbFNpZ24gbnYtc2ExMTAvBgNVBAMTKEdsb2JhbFNpZ24gVGltZXN0YW1w
# aW5nIENBIC0gU0hBMzg0IC0gRzQwHhcNMjUwNDExMTQ0NzM5WhcNMzQxMjEwMDAw
# MDAwWjBUMQswCQYDVQQGEwJCRTEZMBcGA1UECgwQR2xvYmFsU2lnbiBudi1zYTEq
# MCgGA1UEAwwhR2xvYmFsc2lnbiBUU0EgZm9yIENvZGVTaWduMSAtIFI2MIIBojAN
# BgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAolvEqk1J5SN4PuCF6+aqCj7V8qyo
# p0Rh94rLmY37Cn8er80SkfKzdJHJk3Tqa9QY4UwV6hedXfSb5gk0Xydy3MNEj1qE
# +ZomPEcjC7uRtGdfB/PtnieWJzjtPVUlmEPrUMsoFU7woJScRV1W6/6efi2BySHX
# shZ30V1EDZ2lKQ0DK3q3bI4sJE/5n/dQy8iL4hjTaS9v0YQy5RJY+o1NWhxP/HsN
# um67Or4rFDsGIE85hg5r4g3CXFuiqWvlNmPbCBWgdxp/PCqY0Lie04DuKbDwRd6n
# rm5AH5oIRJyFUjLvG4HO0L1UXYMuJ6J1JzO438RA0mJRvU2ZwbI6yiFHaS0x3SgF
# akvhELLn4tmwngYPj+FDX3LaWHnni/MGJXRxnN0pQdYJqEYhKUlrMH9+2Klndcz/
# 9yXYGEywTt88d3y+TUFvZlAA0BMOYMMrYFQEptlRg2DYrx5sWtX1qvCzk6sEBLRV
# PEbE0i+J01ILlBzRpcJusZUQyGK2RVSOFfXPAgMBAAGjggGoMIIBpDAOBgNVHQ8B
# Af8EBAMCB4AwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwHQYDVR0OBBYEFIBDTPy6
# bR0T0nUSiAl3b9vGT5VUMFYGA1UdIARPME0wCAYGZ4EMAQQCMEEGCSsGAQQBoDIB
# HjA0MDIGCCsGAQUFBwIBFiZodHRwczovL3d3dy5nbG9iYWxzaWduLmNvbS9yZXBv
# c2l0b3J5LzAMBgNVHRMBAf8EAjAAMIGQBggrBgEFBQcBAQSBgzCBgDA5BggrBgEF
# BQcwAYYtaHR0cDovL29jc3AuZ2xvYmFsc2lnbi5jb20vY2EvZ3N0c2FjYXNoYTM4
# NGc0MEMGCCsGAQUFBzAChjdodHRwOi8vc2VjdXJlLmdsb2JhbHNpZ24uY29tL2Nh
# Y2VydC9nc3RzYWNhc2hhMzg0ZzQuY3J0MB8GA1UdIwQYMBaAFOoWxmnn48tXRTkz
# pPBAvtDDvWWWMEEGA1UdHwQ6MDgwNqA0oDKGMGh0dHA6Ly9jcmwuZ2xvYmFsc2ln
# bi5jb20vY2EvZ3N0c2FjYXNoYTM4NGc0LmNybDANBgkqhkiG9w0BAQwFAAOCAgEA
# t6bHSpl2dP0gYie9iXw3Bz5XzwsvmiYisEjboyRZin+jqH26IFq7fQMIrN5VdX8K
# Gl5pEe21b8skPfUctiroo6QS5oWESl4kzZow2iJ/qJn76TkvL+v2f4mHolGLBwyD
# m74fXr68W63xuiYSpnbf7NYPyBaHI7zJ/ErST4bA00TC+ftPttS+G/MhNUaKg34y
# aJ8Z6AENnPdCB8VIrt/sqd6R1k89Ojx1jL36QBEPUr2dtIIlS3Ki74CU15YTvG+X
# xt9cwE+0Gx/qRQv8YbF+UcsdgYU4jNRZB0kTV3Bsd3lyIWmt8DT4RQj9LQ1ILOpq
# G/Czwd9q9GJL6jSJeSq1AC4ZocVMuqcYd/D9JpIML9BQ/wk5lgJkgXEc1gRgPsDs
# U9zz36JymN1+Yhvx0Vr67jr0Qfqk3V0z6/xVmEAJKafTeIfD9hQchjiGkyw3EKNi
# yHyM37rdK/BsTSx0rB3MHdqE9/dHQX5NUOQCWUvhkWy10u71yzGKWnbAWQ6NNuq9
# ftcwYFTmcyo5YbFwzfkyS+Y78+O9utqgi6VoE2NzVJbucqGLZtJFJzGJD7xe/rqU
# LwYHeQ3HPSnNCagb6jqBeFSnXTx0GbuYuk3jA51dQNtsogVAGXCqHsh62QVAl/ga
# dTfcRaMpIWAc3CPup3x19dDApspmRyOVzXBUtsiCWsIwggZZMIIEQaADAgECAg0B
# 7BySQN79LkBdfEd0MA0GCSqGSIb3DQEBDAUAMEwxIDAeBgNVBAsTF0dsb2JhbFNp
# Z24gUm9vdCBDQSAtIFI2MRMwEQYDVQQKEwpHbG9iYWxTaWduMRMwEQYDVQQDEwpH
# bG9iYWxTaWduMB4XDTE4MDYyMDAwMDAwMFoXDTM0MTIxMDAwMDAwMFowWzELMAkG
# A1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExMTAvBgNVBAMTKEds
# b2JhbFNpZ24gVGltZXN0YW1waW5nIENBIC0gU0hBMzg0IC0gRzQwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDwAuIwI/rgG+GadLOvdYNfqUdSx2E6Y3w5
# I3ltdPwx5HQSGZb6zidiW64HiifuV6PENe2zNMeswwzrgGZt0ShKwSy7uXDycq6M
# 95laXXauv0SofEEkjo+6xU//NkGrpy39eE5DiP6TGRfZ7jHPvIo7bmrEiPDul/bc
# 8xigS5kcDoenJuGIyaDlmeKe9JxMP11b7Lbv0mXPRQtUPbFUUweLmW64VJmKqDGS
# O/J6ffwOWN+BauGwbB5lgirUIceU/kKWO/ELsX9/RpgOhz16ZevRVqkuvftYPbWF
# +lOZTVt07XJLog2CNxkM0KvqWsHvD9WZuT/0TzXxnA/TNxNS2SU07Zbv+GfqCL6P
# SXr/kLHU9ykV1/kNXdaHQx50xHAotIB7vSqbu4ThDqxvDbm19m1W/oodCT4kDmcm
# x/yyDaCUsLKUzHvmZ/6mWLLU2EESwVX9bpHFu7FMCEue1EIGbxsY1TbqZK7O/fUF
# 5uJm0A4FIayxEQYjGeT7BTRE6giunUlnEYuC5a1ahqdm/TMDAd6ZJflxbumcXQJM
# YDzPAo8B/XLukvGnEt5CEk3sqSbldwKsDlcMCdFhniaI/MiyTdtk8EWfusE/VKPY
# dgKVbGqNyiJc9gwE4yn6S7Ac0zd0hNkdZqs0c48efXxeltY9GbCX6oxQkW2vV4Z+
# EDcdaxoU3wIDAQABo4IBKTCCASUwDgYDVR0PAQH/BAQDAgGGMBIGA1UdEwEB/wQI
# MAYBAf8CAQAwHQYDVR0OBBYEFOoWxmnn48tXRTkzpPBAvtDDvWWWMB8GA1UdIwQY
# MBaAFK5sBaOTE+Ki5+LXHNbH8H/IZ1OgMD4GCCsGAQUFBwEBBDIwMDAuBggrBgEF
# BQcwAYYiaHR0cDovL29jc3AyLmdsb2JhbHNpZ24uY29tL3Jvb3RyNjA2BgNVHR8E
# LzAtMCugKaAnhiVodHRwOi8vY3JsLmdsb2JhbHNpZ24uY29tL3Jvb3QtcjYuY3Js
# MEcGA1UdIARAMD4wPAYEVR0gADA0MDIGCCsGAQUFBwIBFiZodHRwczovL3d3dy5n
# bG9iYWxzaWduLmNvbS9yZXBvc2l0b3J5LzANBgkqhkiG9w0BAQwFAAOCAgEAf+KI
# 2VdnK0JfgacJC7rEuygYVtZMv9sbB3DG+wsJrQA6YDMfOcYWaxlASSUIHuSb99ak
# DY8elvKGohfeQb9P4byrze7AI4zGhf5LFST5GETsH8KkrNCyz+zCVmUdvX/23oLI
# t59h07VGSJiXAmd6FpVK22LG0LMCzDRIRVXd7OlKn14U7XIQcXZw0g+W8+o3V5SR
# GK/cjZk4GVjCqaF+om4VJuq0+X8q5+dIZGkv0pqhcvb3JEt0Wn1yhjWzAlcfi5z8
# u6xM3vreU0yD/RKxtklVT3WdrG9KyC5qucqIwxIwTrIIc59eodaZzul9S5YszBZr
# GM3kWTeGCSziRdayzW6CdaXajR63Wy+ILj198fKRMAWcznt8oMWsr1EG8BHHHTDF
# UVZg6HyVPSLj1QokUyeXgPpIiScseeI85Zse46qEgok+wEr1If5iEO0dMPz2zOpI
# J3yLdUJ/a8vzpWuVHwRYNAqJ7YJQ5NF7qMnmvkiqK1XZjbclIA4bUaDUY6qD6mxy
# YUrJ+kPExlfFnbY8sIuwuRwx773vFNgUQGwgHcIt6AvGjW2MtnHtUiH+Pvafnzka
# rqzSL3ogsfSsqh3iLRSd+pZqHcY8yvPZHL9TTaRHWXyVxENB+SXiLBB+gfkNlKd9
# 8rUJ9dhgckBQlSDUQ0S++qCV5yBZtnjGpGqqIpswggWDMIIDa6ADAgECAg5F5rsD
# gzPDhWVI5v9FUTANBgkqhkiG9w0BAQwFADBMMSAwHgYDVQQLExdHbG9iYWxTaWdu
# IFJvb3QgQ0EgLSBSNjETMBEGA1UEChMKR2xvYmFsU2lnbjETMBEGA1UEAxMKR2xv
# YmFsU2lnbjAeFw0xNDEyMTAwMDAwMDBaFw0zNDEyMTAwMDAwMDBaMEwxIDAeBgNV
# BAsTF0dsb2JhbFNpZ24gUm9vdCBDQSAtIFI2MRMwEQYDVQQKEwpHbG9iYWxTaWdu
# MRMwEQYDVQQDEwpHbG9iYWxTaWduMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAlQfoc8pm+ewUyns89w0I8bRFCyyCtEjG61s8roO4QZIzFKRvf+kqzMaw
# iGvFtonRxrL/FM5RFCHsSt0bWsbWh+5NOhUG7WRmC5KAykTec5RO86eJf094YwjI
# ElBtQmYvTbl5KE1SGooagLcZgQ5+xIq8ZEwhHENo1z08isWyZtWQmrcxBsW+4m0y
# BqYe+bnrqqO4v76CY1DQ8BiJ3+QPefXqoh8q0nAue+e8k7ttU+JIfIwQBzj/ZrJ3
# YX7g6ow8qrSk9vOVShIHbf2MsonP0KBhd8hYdLDUIzr3XTrKotudCd5dRC2Q8YHN
# V5L6frxQBGM032uTGL5rNrI55KwkNrfw77YcE1eTtt6y+OKFt3OiuDWqRfLgnTah
# b1SK8XJWbi6IxVFCRBWU7qPFOJabTk5aC0fzBjZJdzC8cTflpuwhCHX85mEWP3fV
# 2ZGXhAps1AJNdMAU7f05+4PyXhShBLAL6f7uj+FuC7IIs2FmCWqxBjplllnA8DX9
# ydoojRoRh3CBCqiadR2eOoYFAJ7bgNYl+dwFnidZTHY5W+r5paHYgw/R/98wEfmF
# zzNI9cptZBQselhP00sIScWVZBpjDnk99bOMylitnEJFeW4OhxlcVLFltr+Mm9wT
# 6Q1vuC7cZ27JixG1hBSKABlwg3mRl5HUGie/Nx4yB9gUYzwoTK8CAwEAAaNjMGEw
# DgYDVR0PAQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFK5sBaOT
# E+Ki5+LXHNbH8H/IZ1OgMB8GA1UdIwQYMBaAFK5sBaOTE+Ki5+LXHNbH8H/IZ1Og
# MA0GCSqGSIb3DQEBDAUAA4ICAQCDJe3o0f2VUs2ewASgkWnmXNCE3tytok/oR3jW
# ZZipW6g8h3wCitFutxZz5l/AVJjVdL7BzeIRka0jGD3d4XJElrSVXsB7jpl4FkMT
# VlezorM7tXfcQHKso+ubNT6xCCGh58RDN3kyvrXnnCxMvEMpmY4w06wh4OMd+tgH
# M3ZUACIquU0gLnBo2uVT/INc053y/0QMRGby0uO9RgAabQK6JV2NoTFR3VRGHE3b
# mZbvGhwEXKYV73jgef5d2z6qTFX9mhWpb+Gm+99wMOnD7kJG7cKTBYn6fWN7P9Bx
# gXwA6JiuDng0wyX7rwqfIGvdOxOPEoziQRpIenOgd2nHtlx/gsge/lgbKCuobK1e
# bcAF0nu364D+JTf+AptorEJdw+71zNzwUHXSNmmc5nsE324GabbeCglIWYfrexRg
# emSqaUPvkcdM7BjdbO9TLYyZ4V7ycj7PVMi9Z+ykD0xF/9O5MCMHTI8Qv4aW2Zla
# tJlXHKTMuxWJU7osBQ/kxJ4ZsRg01Uyduu33H68klQR4qAO77oHl2l98i0qhkHQl
# p7M+S8gsVr3HyO844lyS8Hn3nIS6dC1hASB+ftHyTwdZX4stQ1LrRgyU4fVmR3l3
# 1VRbH60kN8tFWk6gREjI2LCZxRWECfbWSUnAZbjmGnFuoKjxguhFPmzWAtcKZ4MF
# WsmkEDGCA0kwggNFAgEBMG8wWzELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2Jh
# bFNpZ24gbnYtc2ExMTAvBgNVBAMTKEdsb2JhbFNpZ24gVGltZXN0YW1waW5nIENB
# IC0gU0hBMzg0IC0gRzQCEAEACyAFs5QHYts+NnmUm6kwCwYJYIZIAWUDBAIBoIIB
# LTAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwKwYJKoZIhvcNAQk0MR4wHDAL
# BglghkgBZQMEAgGhDQYJKoZIhvcNAQELBQAwLwYJKoZIhvcNAQkEMSIEICLYntL5
# kXcDwMDPqtJvqj5WmY7jsd6KhCm/wZnZ7wZ5MIGwBgsqhkiG9w0BCRACLzGBoDCB
# nTCBmjCBlwQgcl7yf0jhbmm5Y9hCaIxbygeojGkXBkLI/1ord69gXP0wczBfpF0w
# WzELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExMTAvBgNV
# BAMTKEdsb2JhbFNpZ24gVGltZXN0YW1waW5nIENBIC0gU0hBMzg0IC0gRzQCEAEA
# CyAFs5QHYts+NnmUm6kwDQYJKoZIhvcNAQELBQAEggGAg548ffOdr/Vao2rOAB63
# 10ua61AMQsCfru0+QN/pu8odt7A8Fs3J2G0NjCbquicTouy0kbz9YfMo7hYQVM+3
# 35Cepkc3uu1Y+doLznvFeM11G2KVYa2HQGW/sBQv+P9NfoBzmXV8Lvi2MTKikQOe
# UpSHlILo2iogB+apu3EC9F34tDpH3uJD+JHVNMijIXUpyNgsoEUDhPBqFmqr+IM9
# w+0vezirPa01MwoXJ3Bq1Ez16oYe4k832rF6qF71nw4+woOgTQoGqLKZvdUAdfi6
# KxLid3jhLxK5qY2ASDjCpkE+JzvQHBIf2zI6tevYQlWNRnt0xjcdKXFZismSS3K5
# TpqF0i+kTpwu3Wwaw6Pm3NjVEh/qtuR/R3JoNZ+Sf87tLK2lqFXS/2a6WLL31fGb
# KAvIvWmZxWtqBDfO22BUJKSUlIHfs1YA8IGsTWlIcJoby46lwuJ8ReA9wmevscPD
# iGjIgRAnRcHP1b41KV0zdzM5LsC1hND3bZmJs6irnqYV
# SIG # End signature block
